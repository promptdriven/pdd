# [Feature Request] Add `pdd eval` Command for Prompt Quality Scoring & Regression Testing

## Summary

As PDD matures and teams build larger prompt libraries, there is no built-in mechanism to **systematically evaluate prompt quality over time**. I'd like to propose a `pdd eval` command that brings structured, repeatable evaluation directly into the PDD workflow — treating prompt quality as a first-class, measurable concern.

---

## Problem

Right now, when a developer modifies a prompt, the only way to assess quality degradation is to re-run `pdd sync` and manually inspect output, or rely on unit tests that test functional correctness but **not prompt-level quality signals** such as:

- Output consistency across multiple runs
- Regression against a golden dataset baseline
- Semantic alignment between prompt intent and generated code behavior
- Cost/performance tradeoffs across model strengths (`--strength 0.0` vs `1.0`)

This gap becomes critical at scale. A team managing 50+ prompts has no automated way to know if a wording change silently degraded output quality across the board.

---

## Proposed Solution: `pdd eval`

A new command that runs a prompt against a **golden dataset** and scores the outputs using configurable metrics.

### Basic Usage

```bash
# Evaluate a single prompt against its golden dataset
pdd eval customer_churn_python

# Evaluate all prompts in the project
pdd eval --all

# Compare two model strengths side-by-side
pdd eval customer_churn_python --compare --strength-a 0.3 --strength-b 1.0

# Output results to CSV for tracking over time
pdd eval --all --output-report evals/report_2026_02.csv
```

### Golden Dataset Format

A companion `.golden` file (JSONL) alongside the prompt:

```
prompts/
  customer_churn_python.prompt
  customer_churn_python.golden     ← new
```

Each line in the `.golden` file is a test case:

```jsonl
{"input": "churn_rate([1,0,1,1,0])", "expected_output_contains": "0.6", "description": "basic churn rate calculation"}
{"input": "churn_rate([])", "expected_output_contains": "0.0", "description": "empty list edge case"}
{"input": "churn_rate([0,0,0])", "expected_output_contains": "0.0", "description": "all retained customers"}
```

### Scoring Metrics

| Metric | Description |
|--------|-------------|
| `pass_rate` | % of golden test cases that pass |
| `consistency_score` | Variance across N repeated runs (detects flaky prompts) |
| `semantic_similarity` | Cosine similarity between expected and actual output intent |
| `cost_efficiency` | Tokens used per passing test case |

### Example Output

```
pdd eval customer_churn_python

📊 Eval Results: customer_churn_python
─────────────────────────────────────────
  Golden tests:      8 / 8 passed  ✅
  Pass rate:         100%
  Consistency:       0.97 (3 runs)
  Avg tokens/call:   412
  Estimated cost:    $0.003
  
  Regression vs last run: ✅ No regressions detected
  
  Full report saved to: .pdd/evals/customer_churn_python_2026-02-23.json
```

---

## Why This Matters for PDD Philosophy

PDD treats prompts as the **source of truth**. If prompts are source of truth, they deserve the same quality assurance infrastructure that code has — linters, tests, and CI. `pdd eval` would be the "test suite for your prompts," completing the PDD quality loop:

```
Prompt → Code → Tests → ✅ Eval (NEW)
```

This also enables CI/CD integration:

```yaml
# .github/workflows/pdd-eval.yml
- name: Evaluate all prompts
  run: pdd eval --all --output-report evals/ci_report.csv --fail-below 0.95
```

---

## Implementation Notes

- Golden files could be auto-generated via `pdd eval --create-golden <basename>` by running the prompt N times and saving median outputs as the baseline
- The `--compare` flag would produce a side-by-side diff useful for choosing model strength tradeoffs
- Could integrate with the existing `--output-cost` CSV infrastructure already in PDD
- Semantic similarity scoring could use a lightweight embedding model or simple keyword overlap for cost efficiency

---

## My Background Context

I'm applying for the AI Engineer role at Prompt Driven. I come from an AI evaluation and annotation background (Handshake AI / Project Hedgehog — 100+ model evaluation tasks), and this gap stood out immediately when I reviewed the PDD codebase. Systematic prompt evaluation is something I've implemented in annotation workflows and believe would be a high-value addition to PDD as it scales.

Happy to help prototype this if the team is interested. 🙌

---

**Labels suggested:** `enhancement`, `feature-request`, `eval`, `good-first-issue`
