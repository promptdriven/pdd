# PR Description Template — Copy & Paste This into GitHub

---

## Title:
`feat(examples): Add customer churn prediction ML example`

---

## PR Description:

### Summary

This PR adds a new **Customer Churn Prediction** example to the `examples/` directory, extending PDD's example library into the **machine learning / data science** domain.

Current examples (`hello`, `factorial_calculator`, `calculator`) cover basic Python logic but don't demonstrate PDD on a real-world ML workflow. This example fills that gap with a production-style sklearn pipeline.

---

### Changes

```
examples/customer_churn/
├── prompts/
│   └── customer_churn_python.prompt   ← PDD prompt (source of truth)
├── customer_churn.py                  ← Generated sklearn module
├── example_customer_churn.py          ← Runnable demo script
├── test_customer_churn.py             ← Pytest unit tests (17 tests)
└── README.md                          ← Setup, usage, and PDD commands
```

---

### What the Example Demonstrates

- A complete PDD workflow on an ML use case: `prompt → code → tests → example`
- `sklearn.pipeline.Pipeline` with `ColumnTransformer` for mixed-type preprocessing (numeric, categorical, boolean)
- `LogisticRegression` binary classifier with train/test split and 4 evaluation metrics
- `predict()` function returning churn probability (0.0–1.0) for individual customers
- Edge case handling: missing values, None model, incomplete customer dicts
- 17 pytest unit tests across `TestTrain` and `TestPredict` classes covering happy paths and error cases

---

### How to Run

```bash
pip install pandas numpy scikit-learn pytest

# Run the demo
cd examples/customer_churn
python example_customer_churn.py

# Run the tests
pytest test_customer_churn.py -v

# Regenerate from prompt using PDD
pdd --force sync customer_churn
```

---

### Motivation

As someone applying for the AI Engineer role at Prompt Driven, I wanted to contribute something immediately useful to the codebase. After reviewing the docs and existing examples, the most impactful gap I identified was a **real-world ML example** — something practitioners would actually build with PDD.

This also demonstrates PDD's core value proposition: prompts as the source of truth work just as well for data pipelines and ML models as they do for utility functions.

---

### Checklist

- [x] Follows PDD file naming convention (`customer_churn_python.prompt`)
- [x] Includes `.prompt` source of truth file
- [x] Includes generated `.py` module with type hints and docstrings
- [x] Includes `example_*.py` usage script
- [x] Includes `test_*.py` pytest suite
- [x] Includes `README.md` with setup instructions and PDD commands
- [x] No new dependencies beyond standard ML stack (pandas, numpy, scikit-learn)
- [x] All tests pass locally

---

*Contributor: [Darius Rowser](https://github.com/Drowser2430)*
